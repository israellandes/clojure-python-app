def testme():
    print("hello world")


testme()
